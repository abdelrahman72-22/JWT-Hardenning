// init-db.js
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const dbFile = './users.db';

const db = new sqlite3.Database(dbFile, (err) => {
  if (err) return console.error("DB open error:", err);
  console.log("Connected to", dbFile);
});

db.serialize(async () => {
  // Drop and create users table
  db.run("DROP TABLE IF EXISTS users;");
  db.run(`
    CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL
    );
  `, (err) => { // Added callback to check for errors during creation
    if (err) console.error("Error creating users table:", err.message);
    else console.log("Users table ensured.");
  });

  // --- ADD THIS BLOCK FOR REFRESH TOKENS TABLE ---
  db.run("DROP TABLE IF EXISTS refresh_tokens;"); // Drop existing if any
  db.run(`
    CREATE TABLE refresh_tokens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      token_id TEXT UNIQUE NOT NULL,
      username TEXT NOT NULL,
      created_at INTEGER NOT NULL, -- Unix timestamp (seconds)
      expires_at INTEGER NOT NULL, -- Unix timestamp (seconds)
      FOREIGN KEY(username) REFERENCES users(username) ON DELETE CASCADE
    );
  `, (err) => { // Added callback to check for errors during creation
    if (err) console.error("Error creating refresh_tokens table:", err.message);
    else console.log("Refresh tokens table ensured.");
  });
  // --- END ADDITION ---


  // Insert sample users
  const insert = db.prepare("INSERT INTO users (username,password,role) VALUES (?,?,?)");

  const users = [
    {u: 'alice', p: 'alicepass', r: 'user'},
    {u: 'admin', p: 'adminpass', r: 'admin'}
  ];

  for (const usr of users) {
    const hash = bcrypt.hashSync(usr.p, 10);
    insert.run(usr.u, hash, usr.r);
  }
  insert.finalize();
  console.log("✅ users table created with sample accounts:");
  console.log("   - alice / alicepass (role: user)");
  console.log("   - admin / adminpass (role: admin)");
});

db.close();