const fs = require('fs');
const readline = require('readline');

const LOG_FILE = 'server.log'; // Path to your server's log file

// --- Configuration for Suspicious Activity Thresholds ---
const SUSPICIOUS_THRESHOLDS = {
  FAILED_LOGINS_PER_IP_WINDOW: { count: 5, windowMinutes: 60 }, // 5 failed logins from one IP within 60 minutes
  AUTH_FAILURES_PER_IP_WINDOW: { count: 10, windowMinutes: 60 }, // 10 auth failures (access token) from one IP within 60 minutes
  REFRESH_FAILURES_PER_IP_WINDOW: { count: 5, windowMinutes: 60 }, // 5 refresh failures from one IP within 60 minutes
  UNAUTHORIZED_ADMIN_ATTEMPTS: 2, // 2 unauthorized admin attempts by a user
};

// Store parsed events for windowed analysis
const events = {
  failedLogins: [],    // { ip: '::1', timestamp: Date }
  authFailures: [],    // { ip: '::1', timestamp: Date }
  refreshFailures: [], // { ip: '::1', timestamp: Date }
  unauthorizedAdmin: {}, // { username: count }
};

async function scanLogs() {
  if (!fs.existsSync(LOG_FILE)) {
    console.log(`Error: Log file not found at "${LOG_FILE}". Please ensure your server logs to this file.`);
    console.log(`Tip: Run your server like this: node secure-server.js > server.log 2>&1`);
    return;
  }

  const fileStream = fs.createReadStream(LOG_FILE);
  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity
  });

  console.log(`--- Starting Log Scan for Suspicious Activity in "${LOG_FILE}" ---`);

  for await (const line of rl) {
    const timestampMatch = line.match(/^\[(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z)\]/);
    if (!timestampMatch) continue; // Skip lines without our expected timestamp format

    const timestamp = new Date(timestampMatch[1]);
    const ipMatch = line.match(/IP: ([\d.:]+)/);
    const ip = ipMatch ? ipMatch[1] : 'unknown';
    const usernameMatch = line.match(/Username: (\w+)|User: (\w+)/);
    const username = usernameMatch ? (usernameMatch[1] || usernameMatch[2]) : 'unknown';

    if (line.includes('[Failed Login]')) {
      events.failedLogins.push({ ip, timestamp });
    } else if (line.includes('[Auth Failed]') && line.includes('Access token verification failed')) {
      events.authFailures.push({ ip, timestamp });
    } else if (line.includes('[Refresh Failed]')) {
      events.refreshFailures.push({ ip, timestamp });
    } else if (line.includes('[Auth Failed]') && line.includes('attempted unauthorized admin access')) {
      if (username !== 'unknown') {
        events.unauthorizedAdmin[username] = (events.unauthorizedAdmin[username] || 0) + 1;
      }
    }
  }

  console.log("\n--- Analysis Results ---");

  // Function to analyze events within a rolling window
  function analyzeWindowedEvents(eventList, threshold, eventName) {
    const ipMap = new Map(); // { ip: [{ timestamp1, timestamp2, ... }] }
    for (const event of eventList) {
      if (!ipMap.has(event.ip)) {
        ipMap.set(event.ip, []);
      }
      ipMap.get(event.ip).push(event.timestamp);
    }

    for (const [ip, timestamps] of ipMap.entries()) {
      timestamps.sort((a, b) => a - b); // Ensure sorted by time
      let count = 0;
      let windowStart = 0;

      for (let i = 0; i < timestamps.length; i++) {
        // Remove timestamps older than the window
        while (windowStart < i && (timestamps[i].getTime() - timestamps[windowStart].getTime()) > threshold.windowMinutes * 60 * 1000) {
          windowStart++;
        }
        count = i - windowStart + 1; // Current count in window

        if (count >= threshold.count) {
          console.warn(`[ALERT] IP ${ip} detected with ${count} ${eventName} attempts within ${threshold.windowMinutes} minutes. (First at ${timestamps[windowStart].toLocaleString()}, Last at ${timestamps[i].toLocaleString()})`);
        }
      }
    }
  }

  analyzeWindowedEvents(events.failedLogins, SUSPICIOUS_THRESHOLDS.FAILED_LOGINS_PER_IP_WINDOW, 'failed login');
  analyzeWindowedEvents(events.authFailures, SUSPICIOUS_THRESHOLDS.AUTH_FAILURES_PER_IP_WINDOW, 'access token auth failure');
  analyzeWindowedEvents(events.refreshFailures, SUSPICIOUS_THRESHOLDS.REFRESH_FAILURES_PER_IP_WINDOW, 'refresh token auth failure');

  // Check unauthorized admin attempts
  for (const username in events.unauthorizedAdmin) {
    if (events.unauthorizedAdmin[username] >= SUSPICIOUS_THRESHOLDS.UNAUTHORIZED_ADMIN_ATTEMPTS) {
      console.warn(`[ALERT] User '${username}' attempted unauthorized admin access ${events.unauthorizedAdmin[username]} times.`);
    }
  }

  console.log("\n--- Log Scan Complete ---");
}

scanLogs();