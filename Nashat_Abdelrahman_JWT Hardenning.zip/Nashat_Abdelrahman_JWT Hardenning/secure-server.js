// secure-server.js (HARDENED - with HTTPS)
require('dotenv').config();

const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const sqlite3 = require('sqlite3').verbose();
const cookieParser = require('cookie-parser');
const path = require('path');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const https = require('https'); // <--- ADD THIS
const fs = require('fs');       // <--- ADD THIS (for reading cert files)

const app = express();
app.use(bodyParser.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(helmet());

// --- Certificate Loading ---
const privateKey = fs.readFileSync(path.join(__dirname, 'certs', 'server.key'), 'utf8');
const certificate = fs.readFileSync(path.join(__dirname, 'certs', 'server.crt'), 'utf8');
const credentials = { key: privateKey, cert: certificate };
// --- END Certificate Loading ---

const PORT = 1235; // Use same port, but it will be HTTPS now
const DB = new sqlite3.Database('./users.db');

const ACCESS_SECRET = process.env.ACCESS_SECRET;
const REFRESH_SECRET = process.env.REFRESH_SECRET;
const JWT_ISSUER = process.env.JWT_ISSUER || 'jwt-lab-default';
const JWT_AUDIENCE = process.env.JWT_AUDIENCE || 'web-app-default';

if (!ACCESS_SECRET || !REFRESH_SECRET) {
  console.error(`[${new Date().toISOString()}] [Config Error] ACCESS_SECRET or REFRESH_SECRET not set in .env file.`);
  process.exit(1);
}

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: 'Too many login attempts from this IP, please try again after 15 minutes',
  handler: (req, res, next) => {
    console.warn(`[${new Date().toISOString()}] [Rate Limit Exceeded] IP: ${req.ip} - Route: ${req.path}`);
    res.status(429).json({ error: 'Too many requests. Please try again later.' });
  },
  standardHeaders: true,
  legacyHeaders: false,
});

function issueAccessToken(username, role) {
  return jwt.sign({ sub: username, role, aud: JWT_AUDIENCE }, ACCESS_SECRET, {
    algorithm: 'HS256',
    expiresIn: '15m',
    issuer: JWT_ISSUER
  });
}

function issueRefreshToken(username, tokenId) {
  return jwt.sign({ sub: username, tid: tokenId, aud: JWT_AUDIENCE }, REFRESH_SECRET, {
    algorithm: 'HS256',
    expiresIn: '7d',
    issuer: JWT_ISSUER
  });
}

// Login -> returns access token and sets refresh token in HttpOnly cookie
app.post('/login', loginLimiter, (req, res) => {
  const { username, password } = req.body;
  DB.get("SELECT * FROM users WHERE username = ?", [username], (err, row) => {
    if (err) {
      console.error(`[${new Date().toISOString()}] [DB Error] Login query for ${username}: ${err.message}`);
      return res.status(500).json({ error: 'db error' });
    }
    if (!row || !bcrypt.compareSync(password, row.password)) {
      console.warn(`[${new Date().toISOString()}] [Failed Login] IP: ${req.ip} - Username: ${username}`);
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const accessToken = issueAccessToken(row.username, row.role);
    const tokenId = Math.random().toString(36).slice(2);
    const refreshToken = issueRefreshToken(row.username, tokenId);

    const expiresInMs = 7 * 24 * 60 * 60 * 1000;
    const expiresAt = Math.floor((Date.now() + expiresInMs) / 1000);

    DB.run(
      "INSERT INTO refresh_tokens (token_id, username, created_at, expires_at) VALUES (?, ?, ?, ?)",
      [tokenId, row.username, Math.floor(Date.now() / 1000), expiresAt],
      function (dbErr) {
        if (dbErr) {
          console.error(`[${new Date().toISOString()}] [DB Error] Failed to store refresh token for ${row.username}: ${dbErr.message}`);
          return res.status(500).json({ error: 'Failed to create refresh token session' });
        }
        console.log(`[${new Date().toISOString()}] [Successful Login] IP: ${req.ip} - User: ${row.username} (Token ID: ${tokenId})`);

        res.cookie('refreshToken', refreshToken, {
          httpOnly: true,
          secure: true, // <--- IMPORTANT: SET TO TRUE FOR HTTPS
          sameSite: 'Strict',
          maxAge: expiresInMs
        });

        return res.json({ accessToken, expiresIn: 900 });
      }
    );
  });
});

function authMiddleware(req, res, next) {
  const auth = (req.headers.authorization || '');
  const token = auth.replace('Bearer ', '');
  if (!token) {
    console.warn(`[${new Date().toISOString()}] [Auth Failed] IP: ${req.ip} - No access token provided for route: ${req.path}`);
    return res.status(401).json({ error: 'No token' });
  }
  try {
    const payload = jwt.verify(token, ACCESS_SECRET, {
      algorithms: ['HS256'],
      issuer: JWT_ISSUER,
      audience: JWT_AUDIENCE
    });
    req.user = payload;
    next();
  } catch (e) {
    console.error(`[${new Date().toISOString()}] [Auth Failed] IP: ${req.ip} - Access token verification failed: ${e.message}`);
    return res.status(401).json({ error: 'Invalid token' });
  }
}

app.get('/admin', authMiddleware, (req, res) => {
  if (req.user.role === 'admin') {
    console.log(`[${new Date().toISOString()}] [Admin Access] IP: ${req.ip} - User: ${req.user.sub}`);
    return res.json({ secret: 'VERY SENSITIVE ADMIN DATA (SECURE)' });
  }
  console.warn(`[${new Date().toISOString()}] [Auth Failed] IP: ${req.ip} - User: ${req.user.sub} attempted unauthorized admin access`);
  return res.status(403).json({ error: 'Forbidden' });
});

app.post('/refresh', (req, res) => {
  const cookieRefreshToken = req.cookies.refreshToken;
  const clientIp = req.ip;
  if (!cookieRefreshToken) {
    console.warn(`[${new Date().toISOString()}] [Refresh Failed] IP: ${clientIp} - No refresh token cookie found.`);
    return res.status(401).json({ error: 'No refresh token provided' });
  }

  try {
    const payload = jwt.verify(cookieRefreshToken, REFRESH_SECRET, {
      algorithms: ['HS256'],
      issuer: JWT_ISSUER,
      audience: JWT_AUDIENCE
    });

    DB.get(
      "SELECT * FROM refresh_tokens WHERE token_id = ? AND username = ? AND expires_at > ?",
      [payload.tid, payload.sub, Math.floor(Date.now() / 1000)],
      (err, storedToken) => {
        if (err) {
          console.error(`[${new Date().toISOString()}] [DB Error] Refresh token lookup for ${payload.sub} (tid: ${payload.tid}): ${err.message}`);
          return res.status(500).json({ error: 'Internal server error during refresh' });
        }
        if (!storedToken) {
          console.warn(`[${new Date().toISOString()}] [Refresh Failed] IP: ${clientIp} - Invalid or expired refresh token_id: ${payload.tid} for user: ${payload.sub}`);
          return res.status(401).json({ error: 'Invalid or expired refresh token' });
        }

        DB.run(
          "DELETE FROM refresh_tokens WHERE token_id = ?",
          [payload.tid],
          function (deleteErr) {
            if (deleteErr) {
              console.error(`[${new Date().toISOString()}] [DB Error] Failed to delete old refresh token_id ${payload.tid}: ${deleteErr.message}`);
            } else {
              console.log(`[${new Date().toISOString()}] [Refresh Success] Old refresh token_id deleted: ${payload.tid}`);
            }

            DB.get("SELECT role FROM users WHERE username = ?", [payload.sub], (roleErr, row) => {
              if (roleErr || !row) {
                console.error(`[${new Date().toISOString()}] [DB Error] Error fetching role for ${payload.sub} during refresh: ${roleErr ? roleErr.message : 'Role not found'}`);
                return res.status(500).json({ error: 'Internal server error during refresh' });
              }
              const newAccessToken = issueAccessToken(payload.sub, row.role);
              const newTid = Math.random().toString(36).slice(2);
              const newRefreshToken = issueRefreshToken(payload.sub, newTid);

              const newExpiresInMs = 7 * 24 * 60 * 60 * 1000;
              const newExpiresAt = Math.floor((Date.now() + newExpiresInMs) / 1000);

              DB.run(
                "INSERT INTO refresh_tokens (token_id, username, created_at, expires_at) VALUES (?, ?, ?, ?)",
                [newTid, payload.sub, Math.floor(Date.now() / 1000), newExpiresAt],
                function (insertErr) {
                  if (insertErr) {
                    console.error(`[${new Date().toISOString()}] [DB Error] Failed to store new refresh token for ${payload.sub}: ${insertErr.message}`);
                    return res.status(500).json({ error: 'Failed to create new refresh token session' });
                  }
                  console.log(`[${new Date().toISOString()}] [Refresh Success] New refresh token session created for ${payload.sub} with token_id: ${newTid}`);

                  res.cookie('refreshToken', newRefreshToken, {
                    httpOnly: true,
                    secure: true, // <--- IMPORTANT: SET TO TRUE FOR HTTPS
                    sameSite: 'Strict',
                    maxAge: newExpiresInMs
                  });
                  return res.json({ accessToken: newAccessToken });
                }
              );
            });
          }
        );
      }
    );
  } catch (e) {
    console.error(`[${new Date().toISOString()}] [Refresh Failed] IP: ${clientIp} - JWT verification failed for refresh token: ${e.message}`);
    res.clearCookie('refreshToken', { httpOnly: true, secure: true, sameSite: 'Strict' }); // <--- IMPORTANT: SET TO TRUE FOR HTTPS
    return res.status(401).json({ error: 'Invalid refresh token signature or malformed' });
  }
});

// Replace app.listen(PORT, ...) with https.createServer
const httpsServer = https.createServer(credentials, app);

httpsServer.listen(PORT, () => console.log(`[${new Date().toISOString()}] SECURE HTTPS server running at https://localhost:${PORT}`)); // Updated log message